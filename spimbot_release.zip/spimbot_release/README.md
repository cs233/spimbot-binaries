# How to work with spimbot

1. have docker daemon running

2. run the following command inside your terminal:

    ```sh
    docker compose pull 
    docker compose up -d
    ```
